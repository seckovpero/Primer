//
//  RWPickFlavor.h
//  RWPickFlavor
//
//  Created by AspidaMacBook on 13/03/2018.
//  Copyright © 2018 AspidaMacBook. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for RWPickFlavor.
FOUNDATION_EXPORT double RWPickFlavorVersionNumber;

//! Project version string for RWPickFlavor.
FOUNDATION_EXPORT const unsigned char RWPickFlavorVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <RWPickFlavor/PublicHeader.h>


