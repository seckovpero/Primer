//
//  Primer.h
//  RWPickFlavor
//
//  Created by AspidaMacBook on 19/03/2018.
//  Copyright © 2018 AspidaMacBook. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Primer : UIView

@end
